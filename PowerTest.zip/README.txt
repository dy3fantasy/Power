walkingHome.csv
A short slow mile walk.
Kept app on.

waterview.csv
A drive down waterview with frequent stops.
Kept app on.

offOnTest.csv
A drive in the parking lot. Turned phone on 
and off, while hopefully recording data.
Failed.
When phone went to sleep app skipped recording
data.